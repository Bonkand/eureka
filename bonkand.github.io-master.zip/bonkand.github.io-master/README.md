# bonkand.github.io
This is my personal website that is shown at https://bonkand.github.io. I forked this from AlexFlipnote and Prizafal and edited it to make it partially my own using a fair chunk of their code.

## Requirements
- Python 3.6 or above

## License information
| Component | License |
| --------- | ------- |
| Source code | [GPL 3.0](https://github.com/AlexFlipnote/alexflipnote.github.io/blob/master/LICENSE) |
| Avatars/Logos | [CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/) |
| Modesta | [MIT](https://github.com/AlexFlipnote/Modesta/blob/master/LICENSE) |
